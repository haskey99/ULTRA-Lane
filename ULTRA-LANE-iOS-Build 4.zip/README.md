
# ULTRA LANE - iOS Build

This is your game ready for iOS.

## How to get .ipa on your Windows ASUS Celeron (FREE)

1. Go to codemagic.io - sign up free
2. Click "Add application" > Choose "Codemagic YAML" > Connect this zip as Git repo OR upload via GitHub
   - Easiest: Create free GitHub repo, upload these files, connect GitHub to Codemagic
3. Codemagic will auto detect codemagic.yaml and build.
   - Select workflow: ios-unsigned-ipa
   - Start build. Takes ~5 mins. Uses 5 of your 500 free mins.
4. Download artifact: ULTRA-LANE-unsigned.ipa

5. On your Windows ASUS:
   - Install iTunes (apple.com)
   - Install Sideloadly (sideloadly.io)
   - Plug iPhone, Trust
   - Drag ULTRA-LANE-unsigned.ipa into Sideloadly, enter Apple ID, Start

Done. App lasts 7 days, then re-do Sideloadly.

## Even faster: Just Add to Home Screen (no expiry)
Host the dist/ folder on Netlify (drag & drop free) and on iPhone Safari -> Share -> Add to Home Screen. Feels like app, never expires.

## Your game fixes made:
- Replaced window.storage (artifact only) with localStorage so highscore works on iPhone
